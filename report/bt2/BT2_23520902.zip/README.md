### How to run
```python3 Sokoban.py```
